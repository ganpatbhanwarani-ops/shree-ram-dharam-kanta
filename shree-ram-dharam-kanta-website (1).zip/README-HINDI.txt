श्री राम धर्म कांटा — Beginner Setup

1) इस ZIP को extract करें।
2) index.html पर double-click करके खोल सकते हैं, लेकिन QR camera browser security के कारण local file पर न चले तो नीचे वाला तरीका अपनाएँ।
3) FREE LIVE WEBSITE:
   - github.com पर account बनाइए।
   - New repository बनाइए: shree-ram-dharam-kanta
   - इस folder की index.html, style.css, app.js files upload करें।
   - Settings > Pages > Deploy from branch > main > /(root) > Save.
   - कुछ मिनट बाद GitHub Pages का live address मिलेगा।

4) यह शुरुआती version:
   - RST, vehicle, party, item, from/to
   - Gross/Tare से Net weight
   - Charge और payment mode
   - Ticket print
   - Ticket में QR generate
   - QR camera scan करके ticket data भरना
   - Browser localStorage में saved tickets

5) IMPORTANT:
   यह demo data सिर्फ उसी browser/device में रखता है। अलग-अलग मोबाइल/कंप्यूटर पर एक ही database चाहिए तो Supabase/Firebase backend जोड़ना होगा।

6) असली weighbridge machine integration:
   Machine से वजन अपने-आप वेबसाइट में लेने के लिए मशीन के indicator/serial/USB/LAN protocol की जानकारी चाहिए। केवल फोटो से यह तय नहीं हो सकता।

अगला चरण:
   Supabase database + login + online ticket history + search + Excel/PDF export + role-based operator/admin + secure QR verification जोड़ें।
