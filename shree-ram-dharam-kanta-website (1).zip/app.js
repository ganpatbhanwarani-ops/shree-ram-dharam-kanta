let scanner;

function val(id){return document.getElementById(id).value.trim()}
function calculate(){
  const g=Number(val('gross'))||0, t=Number(val('tare'))||0;
  document.getElementById('net').textContent=Math.max(0,g-t);
}
function makePayload(){
  calculate();
  return JSON.stringify({
    rst:val('rst'),vehicle:val('vehicle'),party:val('party'),item:val('item'),
    from:val('from'),to:val('to'),gross:Number(val('gross'))||0,tare:Number(val('tare'))||0,
    net:Math.max(0,(Number(val('gross'))||0)-(Number(val('tare'))||0)),
    charge:Number(val('charge'))||0,pay:val('pay'),createdAt:new Date().toISOString()
  });
}
function fillPrint(d){
  const map={rst:'p-rst',vehicle:'p-vehicle',party:'p-party',item:'p-item',from:'p-from',to:'p-to',gross:'p-gross',tare:'p-tare',net:'p-net',charge:'p-charge'};
  Object.entries(map).forEach(([a,b])=>document.getElementById(b).textContent=d[a]??'-');
  document.getElementById('qrcode').innerHTML='';
  new QRCode(document.getElementById('qrcode'),{text:JSON.stringify(d),width:120,height:120});
}
function saveTicket(){
  const d=JSON.parse(makePayload());
  const all=JSON.parse(localStorage.getItem('tickets')||'[]');
  all.unshift(d); localStorage.setItem('tickets',JSON.stringify(all));
  fillPrint(d); renderTickets(); alert('Ticket save हो गया।');
}
function printTicket(){ fillPrint(JSON.parse(makePayload())); window.print(); }
function clearForm(){document.querySelectorAll('input').forEach(x=>{if(x.id!=='item'&&x.id!=='charge')x.value=''});document.getElementById('net').textContent='0'}
function renderTickets(){
  const all=JSON.parse(localStorage.getItem('tickets')||'[]');
  document.getElementById('tickets').innerHTML=all.map((d,i)=>`<tr><td>${d.rst}</td><td>${d.vehicle}</td><td>${d.party}</td><td>${d.net}</td><td><button onclick="loadTicket(${i})">Open</button></td></tr>`).join('');
}
function loadTicket(i){
  const d=JSON.parse(localStorage.getItem('tickets')||'[]')[i];
  ['rst','vehicle','party','item','from','to','gross','tare','charge','pay'].forEach(k=>{if(d[k]!==undefined)document.getElementById(k).value=d[k]});
  calculate(); fillPrint(d);
}
function startScanner(){
  if(!window.Html5Qrcode){alert('QR library अभी load नहीं हुई। Internet चालू रखें और फिर प्रयास करें।');return}
  if(scanner)return;
  scanner=new Html5Qrcode("reader");
  scanner.start({facingMode:"environment"},{fps:10,qrbox:{width:250,height:250}},
    text=>{document.getElementById('scanResult').textContent=text; try{
      const d=JSON.parse(text);
      ['rst','vehicle','party','item','from','to','gross','tare','charge','pay'].forEach(k=>{if(d[k]!==undefined)document.getElementById(k).value=d[k]});
      calculate(); fillPrint(d);
    }catch(e){}},
    err=>{}
  ).catch(e=>alert('Camera शुरू नहीं हो पाया: '+e));
}
renderTickets();